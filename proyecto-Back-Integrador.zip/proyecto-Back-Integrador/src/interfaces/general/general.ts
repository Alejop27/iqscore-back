export default interface PosicionLiga  {
    idPosicion?: number;
    idLiga: number;
    idEquipo: number;
    posicion: number;
    puntos: number;
    ultimo_partido_1: string;
    ultimo_partido_2: string;
    ultimo_partido_3: string;
    ultimo_partido_4: string;
    ultimo_partido_5: string;
}