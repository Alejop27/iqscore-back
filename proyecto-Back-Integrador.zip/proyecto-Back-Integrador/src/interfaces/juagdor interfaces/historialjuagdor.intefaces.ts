export default interface HistorialEquipo {
    idJugador: number;
    nombre_equipo: string;
    año_inicio: number;
    año_fin: number;
    foto_equipo?: string; 
}
