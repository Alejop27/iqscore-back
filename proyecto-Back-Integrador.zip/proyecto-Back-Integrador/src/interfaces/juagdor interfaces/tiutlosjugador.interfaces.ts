export default interface Titulo {
    idJugador?: number;
    nombre_titulo: string;
    año: number;
}
